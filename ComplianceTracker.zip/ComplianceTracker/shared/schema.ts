import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  companyId: integer("company_id").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
  companyId: true,
});

// Company profile schema
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  industry: text("industry").notNull(),
  size: text("size").notNull(),
  location: text("location").notNull(),
  complianceScore: integer("compliance_score").default(0),
  documentComplianceScore: integer("document_compliance_score").default(0),
  trainingComplianceScore: integer("training_compliance_score").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCompanySchema = createInsertSchema(companies).pick({
  name: true,
  industry: true,
  size: true,
  location: true,
});

// Regulatory alerts schema
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  severity: text("severity").notNull(), // 'high', 'medium', 'low'
  industry: text("industry").notNull(),
  relevantTo: text("relevant_to").array(), // Array of industries this alert is relevant to
  postDate: timestamp("post_date").defaultNow(),
  expiryDate: timestamp("expiry_date"),
  isRead: boolean("is_read").default(false),
});

export const insertAlertSchema = createInsertSchema(alerts).pick({
  title: true,
  description: true,
  category: true,
  severity: true,
  industry: true,
  relevantTo: true,
  expiryDate: true,
});

// Compliance requirements schema
export const requirements = pgTable("requirements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  dueDate: timestamp("due_date"),
  status: text("status").notNull(), // 'compliant', 'in_progress', 'non_compliant', 'urgent'
  industry: text("industry").notNull(),
  companyId: integer("company_id").notNull(),
});

export const insertRequirementSchema = createInsertSchema(requirements).pick({
  name: true,
  description: true,
  category: true,
  dueDate: true,
  status: true,
  industry: true,
  companyId: true,
});

// Industry categories
export const industries = [
  "Healthcare",
  "Financial Services",
  "Retail",
  "Manufacturing",
  "Technology",
  "Education",
  "Construction",
  "Hospitality",
  "Transportation",
  "Energy",
  "Agriculture",
  "Other"
];

// Requirement categories
export const categories = [
  "Data Privacy",
  "Health & Safety",
  "Employment",
  "Financial",
  "Environmental",
  "Tax",
  "Industry-Specific"
];

// Compliance statuses
export const statuses = [
  "Compliant",
  "In Progress",
  "Non-Compliant",
  "Urgent",
  "On Track"
];

// Export types for use throughout the application
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Company = typeof companies.$inferSelect;
export type InsertCompany = z.infer<typeof insertCompanySchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type Requirement = typeof requirements.$inferSelect;
export type InsertRequirement = z.infer<typeof insertRequirementSchema>;
