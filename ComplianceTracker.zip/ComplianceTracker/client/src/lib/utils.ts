import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  if (!date) return '';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(dateObj);
}

export function formatDateWithTime(date: string | Date): string {
  if (!date) return '';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).format(dateObj);
}

export function getTimeSince(date: string | Date): string {
  if (!date) return '';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const seconds = Math.floor((now.getTime() - dateObj.getTime()) / 1000);
  
  let interval = Math.floor(seconds / 31536000); // years
  if (interval >= 1) {
    return `${interval} year${interval === 1 ? '' : 's'} ago`;
  }
  
  interval = Math.floor(seconds / 2592000); // months
  if (interval >= 1) {
    return `${interval} month${interval === 1 ? '' : 's'} ago`;
  }
  
  interval = Math.floor(seconds / 604800); // weeks
  if (interval >= 1) {
    return `${interval} week${interval === 1 ? '' : 's'} ago`;
  }
  
  interval = Math.floor(seconds / 86400); // days
  if (interval >= 1) {
    return `${interval} day${interval === 1 ? '' : 's'} ago`;
  }
  
  interval = Math.floor(seconds / 3600); // hours
  if (interval >= 1) {
    return `${interval} hour${interval === 1 ? '' : 's'} ago`;
  }
  
  interval = Math.floor(seconds / 60); // minutes
  if (interval >= 1) {
    return `${interval} minute${interval === 1 ? '' : 's'} ago`;
  }
  
  return `${Math.floor(seconds)} second${seconds === 1 ? '' : 's'} ago`;
}

export function getSeverityColor(severity: string): { bg: string, text: string } {
  switch (severity.toLowerCase()) {
    case 'high':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    case 'medium':
      return { bg: 'bg-yellow-100', text: 'text-yellow-800' };
    case 'low':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    default:
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
  }
}

export function getStatusColor(status: string): { bg: string, text: string } {
  switch (status.toLowerCase()) {
    case 'compliant':
    case 'on track':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'in progress':
      return { bg: 'bg-yellow-100', text: 'text-yellow-800' };
    case 'non-compliant':
    case 'urgent':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    default:
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
  }
}

export function getCategoryColor(category: string): { bg: string, text: string } {
  switch (category.toLowerCase()) {
    case 'data privacy':
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
    case 'health & safety':
      return { bg: 'bg-yellow-100', text: 'text-yellow-800' };
    case 'employment':
      return { bg: 'bg-purple-100', text: 'text-purple-800' };
    case 'financial':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'environmental':
      return { bg: 'bg-emerald-100', text: 'text-emerald-800' };
    case 'tax':
      return { bg: 'bg-indigo-100', text: 'text-indigo-800' };
    case 'industry-specific':
      return { bg: 'bg-orange-100', text: 'text-orange-800' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-800' };
  }
}
