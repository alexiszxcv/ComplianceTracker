import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { RefreshCw, CheckCircle, AlertTriangle } from "lucide-react";
import { formatDateWithTime } from "@/lib/utils";

export function ComplianceOverview() {
  const { data: company, isLoading, refetch } = useQuery({
    queryKey: ['/api/companies/1'],
  });

  const handleRefresh = () => {
    refetch();
  };

  const lastUpdated = new Date();

  return (
    <div className="mb-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
        <div>
          <h3 className="text-xl font-semibold text-neutral-800">Compliance Status Overview</h3>
          <p className="text-neutral-500 text-sm">Last updated: {formatDateWithTime(lastUpdated)}</p>
        </div>
        <div className="mt-3 md:mt-0">
          <Button 
            variant="outline" 
            onClick={handleRefresh}
            className="flex items-center justify-center py-2 px-4 text-sm font-medium text-primary bg-primary/10"
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh Status
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {isLoading ? (
          <>
            <ComplianceCardSkeleton />
            <ComplianceCardSkeleton />
            <ComplianceCardSkeleton />
          </>
        ) : (
          <>
            <ComplianceCard
              title="Overall Compliance"
              score={company?.complianceScore || 0}
              icon={company?.complianceScore >= 80 ? <CheckCircle className="h-5 w-5 text-green-500" /> : <AlertTriangle className="h-5 w-5 text-yellow-500" />}
              bgColor={company?.complianceScore >= 80 ? "bg-green-500" : "bg-yellow-500"}
              message={company?.complianceScore >= 80 ? "3 items need attention" : "Multiple issues need attention"}
            />
            <ComplianceCard
              title="Document Compliance"
              score={company?.documentComplianceScore || 0}
              icon={company?.documentComplianceScore >= 80 ? <CheckCircle className="h-5 w-5 text-green-500" /> : <AlertTriangle className="h-5 w-5 text-yellow-500" />}
              bgColor={company?.documentComplianceScore >= 80 ? "bg-green-500" : "bg-yellow-500"}
              message={company?.documentComplianceScore >= 80 ? "All documents up to date" : "5 documents need updating"}
            />
            <ComplianceCard
              title="Training Compliance"
              score={company?.trainingComplianceScore || 0}
              icon={company?.trainingComplianceScore >= 80 ? <CheckCircle className="h-5 w-5 text-green-500" /> : <AlertTriangle className="h-5 w-5 text-yellow-500" />}
              bgColor={company?.trainingComplianceScore >= 80 ? "bg-green-500" : "bg-yellow-500"}
              message={company?.trainingComplianceScore >= 80 ? "1 training session expiring soon" : "Multiple trainings need attention"}
            />
          </>
        )}
      </div>
    </div>
  );
}

interface ComplianceCardProps {
  title: string;
  score: number;
  icon: React.ReactNode;
  bgColor: string;
  message: string;
}

function ComplianceCard({ title, score, icon, bgColor, message }: ComplianceCardProps) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-neutral-500">{title}</p>
          <h4 className="text-xl font-semibold mt-1 text-neutral-900">{score}%</h4>
        </div>
        <div className={`w-10 h-10 rounded-full ${bgColor} bg-opacity-10 flex items-center justify-center`}>
          {icon}
        </div>
      </div>
      <div className="mt-4">
        <div className="w-full bg-neutral-200 rounded-full h-2">
          <div
            className={`${bgColor} rounded-full h-2`}
            style={{ width: `${score}%` }}
          ></div>
        </div>
      </div>
      <div className="mt-3 text-sm text-neutral-600">
        <p>{message}</p>
      </div>
    </Card>
  );
}

function ComplianceCardSkeleton() {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div>
          <Skeleton className="h-4 w-32 mb-2" />
          <Skeleton className="h-6 w-16" />
        </div>
        <Skeleton className="h-10 w-10 rounded-full" />
      </div>
      <div className="mt-4">
        <Skeleton className="h-2 w-full rounded-full" />
      </div>
      <div className="mt-3">
        <Skeleton className="h-4 w-40" />
      </div>
    </Card>
  );
}
