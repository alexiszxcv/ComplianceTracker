import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ExternalLink, ClipboardEdit } from "lucide-react";
import { getCategoryColor, getStatusColor } from "@/lib/utils";

interface Requirement {
  id: number;
  name: string;
  description: string;
  category: string;
  dueDate: string;
  status: string;
}

export function ComplianceRequirements() {
  const [category, setCategory] = useState("All Categories");
  const [status, setStatus] = useState("All Statuses");

  const { data: requirements, isLoading } = useQuery<Requirement[]>({
    queryKey: ['/api/requirements'],
  });

  const { data: categories } = useQuery<string[]>({
    queryKey: ['/api/utils/categories'],
  });

  const { data: statuses } = useQuery<string[]>({
    queryKey: ['/api/utils/statuses'],
  });

  // Filter requirements based on category and status
  const filteredRequirements = requirements?.filter(req => {
    if (category !== "All Categories" && req.category !== category) return false;
    if (status !== "All Statuses" && req.status !== status) return false;
    return true;
  });

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
        <h3 className="text-xl font-semibold text-neutral-800">Compliance Requirements</h3>
        <div className="flex items-center space-x-3 mt-3 md:mt-0">
          <div className="relative">
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All Categories">All Categories</SelectItem>
                {categories?.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="relative">
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All Statuses">All Statuses</SelectItem>
                {statuses?.map(stat => (
                  <SelectItem key={stat} value={stat}>{stat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          {isLoading ? (
            <RequirementsTableSkeleton />
          ) : (
            <Table>
              <TableHeader className="bg-neutral-50">
                <TableRow>
                  <TableHead className="w-96">Requirement</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRequirements && filteredRequirements.length > 0 ? (
                  filteredRequirements.map(requirement => {
                    const categoryColors = getCategoryColor(requirement.category);
                    const statusColors = getStatusColor(requirement.status);
                    
                    return (
                      <TableRow key={requirement.id}>
                        <TableCell className="whitespace-nowrap">
                          <div className="text-sm font-medium text-neutral-900">{requirement.name}</div>
                          <div className="text-sm text-neutral-500">{requirement.description}</div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge className={`${categoryColors.bg} ${categoryColors.text}`}>
                            {requirement.category}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-neutral-600">
                          {requirement.dueDate}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge className={`${statusColors.bg} ${statusColors.text}`}>
                            {requirement.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-neutral-500 space-x-3">
                          <Button variant="link" size="sm" className="text-primary h-auto p-0">
                            <ExternalLink className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button variant="link" size="sm" className="text-primary h-auto p-0">
                            <ClipboardEdit className="h-4 w-4 mr-1" />
                            Update
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center">
                      No requirements found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </div>
        <div className="px-4 py-3 bg-neutral-50 border-t border-neutral-200 sm:px-6 flex items-center justify-between">
          <div className="text-sm text-neutral-700">
            Showing {filteredRequirements?.length || 0} of {requirements?.length || 0} requirements
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4 mr-1" />
              Previous
            </Button>
            <Button variant="outline" size="sm">
              Next
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

function RequirementsTableSkeleton() {
  return (
    <Table>
      <TableHeader className="bg-neutral-50">
        <TableRow>
          <TableHead className="w-96">Requirement</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Due Date</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {[1, 2, 3, 4].map(i => (
          <TableRow key={i}>
            <TableCell>
              <Skeleton className="h-5 w-48 mb-1" />
              <Skeleton className="h-4 w-64" />
            </TableCell>
            <TableCell>
              <Skeleton className="h-6 w-24 rounded-full" />
            </TableCell>
            <TableCell>
              <Skeleton className="h-4 w-24" />
            </TableCell>
            <TableCell>
              <Skeleton className="h-6 w-20 rounded-full" />
            </TableCell>
            <TableCell>
              <div className="flex space-x-3">
                <Skeleton className="h-4 w-12" />
                <Skeleton className="h-4 w-12" />
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
