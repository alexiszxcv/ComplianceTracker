import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { AlertCircle, InfoIcon, Clock, ExternalLink } from "lucide-react";
import { getTimeSince } from "@/lib/utils";

interface Alert {
  id: number;
  title: string;
  description: string;
  category: string;
  severity: string;
  industry: string;
  isRead: boolean;
  postDate: string;
}

export function RecentAlerts() {
  const { data: alerts, isLoading } = useQuery<Alert[]>({
    queryKey: ['/api/alerts'],
  });

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold text-neutral-800">Recent Regulatory Alerts</h3>
        <Link href="/alerts">
          <a className="text-sm font-medium text-primary hover:text-primary/80">
            View All
          </a>
        </Link>
      </div>

      <Card className="overflow-hidden">
        {isLoading ? (
          <AlertsSkeleton />
        ) : (
          <>
            {alerts && alerts.length > 0 ? (
              <>
                {/* Alert with highest priority (first alert) */}
                {alerts[0] && (
                  <div className="p-4 border-l-4 border-destructive bg-destructive bg-opacity-5">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <AlertCircle className="h-5 w-5 text-destructive" />
                      </div>
                      <div className="ml-3">
                        <h4 className="text-sm font-medium text-neutral-900">{alerts[0].title}</h4>
                        <p className="mt-1 text-sm text-neutral-600">{alerts[0].description}</p>
                        <div className="mt-2 flex flex-wrap gap-3">
                          <button 
                            onClick={() => {
                              window.location.href = `/alerts/${alerts[0].id}`;
                            }}
                            className="text-sm font-medium text-primary hover:text-primary/80 flex items-center"
                          >
                            <ExternalLink className="h-4 w-4 mr-1" />
                            View Details
                          </button>
                          <span className="text-sm text-neutral-500 flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            Posted {getTimeSince(alerts[0].postDate)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Regular alerts */}
                {alerts.slice(1).map((alert, index) => (
                  <div key={alert.id} className={`p-4 ${index < alerts.length - 2 ? 'border-b border-neutral-200' : ''}`}>
                    <div className="flex">
                      <div className="flex-shrink-0">
                        {alert.severity === 'high' ? (
                          <AlertCircle className="h-5 w-5 text-yellow-500" />
                        ) : (
                          <InfoIcon className="h-5 w-5 text-blue-500" />
                        )}
                      </div>
                      <div className="ml-3">
                        <h4 className="text-sm font-medium text-neutral-900">{alert.title}</h4>
                        <p className="mt-1 text-sm text-neutral-600">{alert.description}</p>
                        <div className="mt-2 flex flex-wrap gap-3">
                          <button 
                            onClick={() => {
                              window.location.href = `/alerts/${alert.id}`;
                            }}
                            className="text-sm font-medium text-primary hover:text-primary/80 flex items-center"
                          >
                            <ExternalLink className="h-4 w-4 mr-1" />
                            View Details
                          </button>
                          <span className="text-sm text-neutral-500 flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            Posted {getTimeSince(alert.postDate)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </>
            ) : (
              <CardContent className="py-10 text-center">
                <p className="text-neutral-500">No alerts found</p>
              </CardContent>
            )}
          </>
        )}
      </Card>
    </div>
  );
}

function AlertsSkeleton() {
  return (
    <>
      <div className="p-4 border-l-4 border-neutral-200">
        <div className="flex">
          <Skeleton className="h-5 w-5 rounded-full" />
          <div className="ml-3 w-full">
            <Skeleton className="h-5 w-3/4 mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <div className="flex gap-3 mt-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
        </div>
      </div>
      {[1, 2, 3].map((i) => (
        <div key={i} className="p-4 border-b border-neutral-200">
          <div className="flex">
            <Skeleton className="h-5 w-5 rounded-full" />
            <div className="ml-3 w-full">
              <Skeleton className="h-5 w-3/4 mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <div className="flex gap-3 mt-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-32" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </>
  );
}
