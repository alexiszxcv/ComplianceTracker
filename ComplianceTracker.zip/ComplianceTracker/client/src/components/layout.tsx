import { useState, useEffect } from "react";
import { Sidebar } from "@/components/ui/sidebar";
import { MobileNav } from "@/components/ui/mobile-nav";
import { Bell, HelpCircle, Search } from "lucide-react";
import { useLocation } from "wouter";
import { useIsMobile } from "@/hooks/use-mobile";

interface LayoutProps {
  children: React.ReactNode;
}

const pathToTitle: Record<string, string> = {
  "/": "Dashboard",
  "/alerts": "Alerts",
  "/company-profile": "Company Profile",
  "/regulations": "Regulations",
};

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const isMobile = useIsMobile();
  const [searchTerm, setSearchTerm] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const pageTitle = pathToTitle[location] || "Not Found";

  const toggleMobileMenu = () => {
    setMobileMenuOpen(prev => !prev);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50">
      {/* Sidebar for desktop */}
      <Sidebar className="hidden lg:flex" />

      {/* Mobile header */}
      {isMobile && (
        <div className="lg:hidden fixed top-0 left-0 right-0 z-10 bg-white border-b border-neutral-200">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center text-white">
                <span className="material-icons text-lg">security</span>
              </div>
              <h1 className="ml-3 font-bold text-lg text-primary">CompliantPro</h1>
            </div>
            <button 
              className="p-2 rounded-full hover:bg-neutral-100"
              onClick={toggleMobileMenu}
            >
              <span className="material-icons">menu</span>
            </button>
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top navbar (desktop) */}
        <header className="hidden lg:flex items-center justify-between h-16 px-6 border-b border-neutral-200 bg-white">
          <div className="flex items-center">
            <h2 className="text-2xl font-semibold text-neutral-800">{pageTitle}</h2>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search regulations..." 
                className="w-64 px-4 py-2 pr-10 text-sm border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute right-3 top-2.5 h-4 w-4 text-neutral-400" />
            </div>
            <button className="p-2 rounded-full hover:bg-neutral-100 relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
            </button>
            <button className="p-2 rounded-full hover:bg-neutral-100">
              <HelpCircle className="h-5 w-5" />
            </button>
          </div>
        </header>

        {/* Main content area with scrolling */}
        <main className="flex-1 overflow-y-auto p-4 pt-20 lg:pt-4 pb-16 lg:pb-4">
          {children}
        </main>

        {/* Mobile navigation */}
        {isMobile && <MobileNav />}
      </div>
    </div>
  );
}
