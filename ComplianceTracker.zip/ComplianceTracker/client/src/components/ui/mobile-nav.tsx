import { Link, useLocation } from "wouter";
import { LayoutDashboard, Bell, Building2, BookOpen } from "lucide-react";

export function MobileNav() {
  const [location] = useLocation();

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200">
      <div className="flex justify-around">
        <Link href="/">
          <a className={`py-2 px-3 ${location === "/" ? "text-primary" : "text-neutral-500"}`}>
            <div className="flex flex-col items-center">
              <LayoutDashboard className="h-5 w-5" />
              <span className="text-xs mt-1">Dashboard</span>
            </div>
          </a>
        </Link>
        <Link href="/alerts">
          <a className={`py-2 px-3 ${location === "/alerts" ? "text-primary" : "text-neutral-500"}`}>
            <div className="flex flex-col items-center">
              <Bell className="h-5 w-5" />
              <span className="text-xs mt-1">Alerts</span>
            </div>
          </a>
        </Link>
        <Link href="/company-profile">
          <a className={`py-2 px-3 ${location === "/company-profile" ? "text-primary" : "text-neutral-500"}`}>
            <div className="flex flex-col items-center">
              <Building2 className="h-5 w-5" />
              <span className="text-xs mt-1">Company</span>
            </div>
          </a>
        </Link>
        <Link href="/regulations">
          <a className={`py-2 px-3 ${location === "/regulations" ? "text-primary" : "text-neutral-500"}`}>
            <div className="flex flex-col items-center">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs mt-1">Regulations</span>
            </div>
          </a>
        </Link>
      </div>
    </nav>
  );
}
