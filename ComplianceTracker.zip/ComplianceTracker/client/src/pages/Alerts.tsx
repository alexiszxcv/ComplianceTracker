import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Link, useLocation, useParams } from "wouter";
import { 
  Bell, 
  AlertTriangle, 
  Info, 
  Search, 
  Clock, 
  ExternalLink, 
  CheckCircle,
  Filter,
  Calendar,
  ArrowLeft,
  Building
} from "lucide-react";
import { getTimeSince, formatDate } from "@/lib/utils";

interface Alert {
  id: number;
  title: string;
  description: string;
  category: string;
  severity: string;
  industry: string;
  isRead: boolean;
  postDate: string;
}

function AlertDetail() {
  const [, navigate] = useLocation();
  const params = useParams();
  const alertId = parseInt(params.id || '0');
  
  // Use a separate variable to track where to navigate back to
  const goBack = () => {
    // Go back to alerts page
    navigate('/alerts');
  };
  
  const goToDashboard = () => {
    // Go back to dashboard
    navigate('/');
  };
  
  const { data: alert, isLoading } = useQuery<Alert>({
    queryKey: [`/api/alerts/${alertId}`],
    enabled: !!alertId,
  });
  
  const severityClass = {
    high: "bg-red-100 text-red-800 border-red-200",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
    low: "bg-blue-100 text-blue-800 border-blue-200"
  }[alert?.severity || "low"] || "bg-blue-100 text-blue-800 border-blue-200";
  
  const severityIcon = {
    high: <AlertTriangle className="h-5 w-5 text-red-500" />,
    medium: <AlertTriangle className="h-5 w-5 text-yellow-500" />,
    low: <Info className="h-5 w-5 text-blue-500" />
  }[alert?.severity || "low"] || <Info className="h-5 w-5 text-blue-500" />;
  
  if (isLoading) {
    return (
      <div>
        <div className="flex gap-2 mb-4">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={goBack}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Alerts
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={goToDashboard}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-4 w-full mb-4" />
            <Skeleton className="h-4 w-full mb-4" />
            <Skeleton className="h-4 w-full mb-4" />
            <Skeleton className="h-4 w-4/5" />
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (!alert) {
    return (
      <div>
        <div className="flex gap-2 mb-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={goBack}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Alerts
          </Button>
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={goToDashboard}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
        
        <Card>
          <CardContent className="py-10 text-center">
            <p className="text-neutral-500">Alert not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex gap-2 mb-4">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={goBack}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Alerts
        </Button>
        
        <Button 
          variant="outline" 
          size="sm" 
          onClick={goToDashboard}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2 mb-2">
            {severityIcon}
            <Badge className={severityClass}>{alert.severity} Priority</Badge>
            {alert.isRead && (
              <Badge variant="outline" className="bg-green-50">
                <CheckCircle className="h-3 w-3 mr-1" /> Read
              </Badge>
            )}
          </div>
          <CardTitle>{alert.title}</CardTitle>
          <CardDescription className="flex items-center mt-1">
            <Clock className="h-4 w-4 mr-1" />
            Posted {getTimeSince(alert.postDate)}
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <p className="text-neutral-700 whitespace-pre-line mb-6">{alert.description}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border rounded-md p-3 bg-neutral-50">
              <div className="text-sm text-neutral-500 mb-1">Category</div>
              <div className="flex items-center">
                <Badge variant="outline" className="bg-neutral-50">
                  {alert.category}
                </Badge>
              </div>
            </div>
            
            <div className="border rounded-md p-3 bg-neutral-50">
              <div className="text-sm text-neutral-500 mb-1">Relevant Industry</div>
              <div className="flex items-center">
                <Building className="h-4 w-4 mr-1 text-neutral-500" />
                {alert.industry}
              </div>
            </div>
            
            <div className="border rounded-md p-3 bg-neutral-50">
              <div className="text-sm text-neutral-500 mb-1">Publication Date</div>
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1 text-neutral-500" />
                {formatDate(alert.postDate)}
              </div>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="border-t bg-neutral-50 flex justify-between">
          <div className="text-sm text-neutral-500">
            Reference ID: {alert.id}
          </div>
          <Button size="sm" variant="secondary">
            Download PDF
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

export default function Alerts() {
  const params = useParams();
  const id = params.id;
  
  // Show detail view if we have an ID
  if (id) {
    return <AlertDetail />;
  }
  
  const [searchTerm, setSearchTerm] = useState("");
  const [currentTab, setCurrentTab] = useState("all");

  const { data: alerts, isLoading } = useQuery<Alert[]>({
    queryKey: ['/api/alerts'],
  });

  // Filter alerts based on search and tab
  const filteredAlerts = alerts?.filter(alert => {
    // Search filter
    if (searchTerm && !alert.title.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !alert.description.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Tab filter
    if (currentTab === "high" && alert.severity !== "high") return false;
    if (currentTab === "medium" && alert.severity !== "medium") return false;
    if (currentTab === "low" && alert.severity !== "low") return false;
    
    return true;
  });

  const highSeverityCount = alerts?.filter(a => a.severity === "high").length || 0;
  const mediumSeverityCount = alerts?.filter(a => a.severity === "medium").length || 0;
  const lowSeverityCount = alerts?.filter(a => a.severity === "low").length || 0;

  const [, navigate] = useLocation();

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <div className="flex items-center mb-2">
            <Button 
              variant="outline" 
              size="sm"
              className="mr-3"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </div>
          <h1 className="text-2xl font-semibold text-neutral-800 mb-1">Regulatory Alerts</h1>
          <p className="text-neutral-500">Stay updated with important compliance changes and announcements</p>
        </div>
        <div className="mt-4 md:mt-0 relative w-full md:w-64">
          <Input
            placeholder="Search alerts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
        </div>
      </div>

      <Tabs defaultValue="all" value={currentTab} onValueChange={setCurrentTab}>
        <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
          <TabsList>
            <TabsTrigger value="all" className="flex items-center">
              <Bell className="mr-2 h-4 w-4" />
              All Alerts
              <Badge className="ml-2 bg-neutral-200 text-neutral-700">{alerts?.length || 0}</Badge>
            </TabsTrigger>
            <TabsTrigger value="high" className="flex items-center">
              <AlertTriangle className="mr-2 h-4 w-4 text-red-500" />
              High Priority
              <Badge className="ml-2 bg-red-100 text-red-800">{highSeverityCount}</Badge>
            </TabsTrigger>
            <TabsTrigger value="medium" className="flex items-center">
              <AlertTriangle className="mr-2 h-4 w-4 text-yellow-500" />
              Medium Priority
              <Badge className="ml-2 bg-yellow-100 text-yellow-800">{mediumSeverityCount}</Badge>
            </TabsTrigger>
            <TabsTrigger value="low" className="flex items-center">
              <Info className="mr-2 h-4 w-4 text-blue-500" />
              Low Priority
              <Badge className="ml-2 bg-blue-100 text-blue-800">{lowSeverityCount}</Badge>
            </TabsTrigger>
          </TabsList>
          
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filter by Category
          </Button>
        </div>

        <TabsContent value="all" className="mt-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <AlertListSkeleton />
              ) : (
                <div className="divide-y divide-neutral-200">
                  {filteredAlerts && filteredAlerts.length > 0 ? (
                    filteredAlerts.map((alert) => (
                      <AlertItem key={alert.id} alert={alert} />
                    ))
                  ) : (
                    <div className="p-6 text-center">
                      <p className="text-neutral-500">No alerts found</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="high" className="mt-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <AlertListSkeleton />
              ) : (
                <div className="divide-y divide-neutral-200">
                  {filteredAlerts && filteredAlerts.length > 0 ? (
                    filteredAlerts.map((alert) => (
                      <AlertItem key={alert.id} alert={alert} />
                    ))
                  ) : (
                    <div className="p-6 text-center">
                      <p className="text-neutral-500">No high priority alerts found</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="medium" className="mt-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <AlertListSkeleton />
              ) : (
                <div className="divide-y divide-neutral-200">
                  {filteredAlerts && filteredAlerts.length > 0 ? (
                    filteredAlerts.map((alert) => (
                      <AlertItem key={alert.id} alert={alert} />
                    ))
                  ) : (
                    <div className="p-6 text-center">
                      <p className="text-neutral-500">No medium priority alerts found</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="low" className="mt-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <AlertListSkeleton />
              ) : (
                <div className="divide-y divide-neutral-200">
                  {filteredAlerts && filteredAlerts.length > 0 ? (
                    filteredAlerts.map((alert) => (
                      <AlertItem key={alert.id} alert={alert} />
                    ))
                  ) : (
                    <div className="p-6 text-center">
                      <p className="text-neutral-500">No low priority alerts found</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface AlertItemProps {
  alert: Alert;
}

function AlertItem({ alert }: AlertItemProps) {
  const severityIcon = {
    high: <AlertTriangle className="h-5 w-5 text-red-500" />,
    medium: <AlertTriangle className="h-5 w-5 text-yellow-500" />,
    low: <Info className="h-5 w-5 text-blue-500" />
  }[alert.severity] || <Info className="h-5 w-5 text-blue-500" />;

  const badgeClass = {
    high: "bg-red-100 text-red-800",
    medium: "bg-yellow-100 text-yellow-800",
    low: "bg-blue-100 text-blue-800"
  }[alert.severity] || "bg-blue-100 text-blue-800";

  return (
    <div className="p-4 flex items-start gap-3">
      <div className="flex-shrink-0 mt-1">{severityIcon}</div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="font-medium text-neutral-900">{alert.title}</h3>
          <Badge className={badgeClass}>{alert.severity}</Badge>
          {alert.isRead && <Badge variant="outline" className="bg-green-50"><CheckCircle className="h-3 w-3 mr-1" /> Read</Badge>}
        </div>
        <p className="text-neutral-600 mb-2">{alert.description}</p>
        <div className="flex items-center flex-wrap gap-x-4 gap-y-2 text-sm">
          <Link href={`/alerts/${alert.id}`}>
            <Button variant="link" size="sm" className="p-0 h-auto text-primary">
              <ExternalLink className="h-4 w-4 mr-1" />
              View Details
            </Button>
          </Link>
          <Badge variant="outline" className="bg-neutral-50">
            Category: {alert.category}
          </Badge>
          <span className="text-neutral-500 flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            Posted {getTimeSince(alert.postDate)}
          </span>
        </div>
      </div>
    </div>
  );
}

function AlertListSkeleton() {
  return (
    <div className="divide-y divide-neutral-200">
      {[1, 2, 3, 4].map(i => (
        <div key={i} className="p-4 flex items-start gap-3">
          <Skeleton className="h-5 w-5 rounded-full" />
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <Skeleton className="h-5 w-48" />
              <Skeleton className="h-5 w-16 rounded-full" />
            </div>
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-5/6 mb-2" />
            <div className="flex items-center gap-4">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
