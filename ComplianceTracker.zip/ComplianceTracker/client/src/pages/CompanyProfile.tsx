import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  Building2, 
  MapPin, 
  Users, 
  Briefcase, 
  CheckCircle2, 
  AlertTriangle,
  Clock,
  ClipboardList,
  FileText,
  GraduationCap,
  Settings,
  Edit
} from "lucide-react";
import { formatDate } from "@/lib/utils";

interface Company {
  id: number;
  name: string;
  industry: string;
  size: string;
  location: string;
  complianceScore: number;
  documentComplianceScore: number;
  trainingComplianceScore: number;
  createdAt: string;
}

export default function CompanyProfile() {
  const { data: company, isLoading } = useQuery<Company>({
    queryKey: ['/api/companies/1'],
  });

  return (
    <div>
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Company Information */}
        <div className="lg:w-1/3">
          <Card>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>Company Profile</span>
                <Button variant="ghost" size="icon">
                  <Edit className="h-4 w-4" />
                </Button>
              </CardTitle>
              <CardDescription>Manage your company information</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <CompanyProfileSkeleton />
              ) : (
                <>
                  <div className="w-16 h-16 rounded-md flex items-center justify-center bg-primary/10 text-primary mb-4">
                    <Building2 className="h-8 w-8" />
                  </div>
                  
                  <h2 className="text-xl font-bold mb-4">{company?.name}</h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Briefcase className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-neutral-700">Industry</p>
                        <p className="text-sm text-neutral-900">{company?.industry}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Users className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-neutral-700">Company Size</p>
                        <p className="text-sm text-neutral-900">{company?.size}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-neutral-700">Location</p>
                        <p className="text-sm text-neutral-900">{company?.location}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Clock className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-neutral-700">Member Since</p>
                        <p className="text-sm text-neutral-900">{formatDate(company?.createdAt || '')}</p>
                      </div>
                    </div>
                  </div>
                  
                  <Separator className="my-6" />
                  
                  <div className="flex justify-between">
                    <Button variant="outline">Update Profile</Button>
                    <Button variant="ghost" size="icon">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Compliance Dashboard */}
        <div className="lg:w-2/3">
          <Card>
            <CardHeader>
              <CardTitle>Compliance Dashboard</CardTitle>
              <CardDescription>Track your compliance status across different areas</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <ComplianceDashboardSkeleton />
              ) : (
                <>
                  <Tabs defaultValue="overview">
                    <TabsList className="mb-6">
                      <TabsTrigger value="overview">Overview</TabsTrigger>
                      <TabsTrigger value="documents">Documents</TabsTrigger>
                      <TabsTrigger value="training">Training</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="overview">
                      <div className="space-y-6">
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="text-sm font-medium flex items-center">
                              <ClipboardList className="h-4 w-4 mr-2" />
                              Overall Compliance
                            </h3>
                            <span className="text-lg font-semibold">{company?.complianceScore}%</span>
                          </div>
                          <Progress value={company?.complianceScore} className="h-2" />
                          <div className="flex justify-between mt-1 text-xs text-neutral-500">
                            <span>0%</span>
                            <span>100%</span>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <div className="flex justify-between items-center mb-2">
                              <h3 className="text-sm font-medium flex items-center">
                                <FileText className="h-4 w-4 mr-2" />
                                Document Compliance
                              </h3>
                              <span className="text-lg font-semibold">{company?.documentComplianceScore}%</span>
                            </div>
                            <Progress value={company?.documentComplianceScore} className="h-2" />
                          </div>
                          
                          <div>
                            <div className="flex justify-between items-center mb-2">
                              <h3 className="text-sm font-medium flex items-center">
                                <GraduationCap className="h-4 w-4 mr-2" />
                                Training Compliance
                              </h3>
                              <span className="text-lg font-semibold">{company?.trainingComplianceScore}%</span>
                            </div>
                            <Progress value={company?.trainingComplianceScore} className="h-2" />
                          </div>
                        </div>
                        
                        <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                          <h3 className="text-sm font-medium mb-3">Compliance Status</h3>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <CheckCircle2 className="h-4 w-4 text-green-500 mr-2" />
                                <span className="text-sm">Compliant Areas</span>
                              </div>
                              <span className="text-sm font-medium">5</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2" />
                                <span className="text-sm">Needs Attention</span>
                              </div>
                              <span className="text-sm font-medium">3</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <AlertTriangle className="h-4 w-4 text-red-500 mr-2" />
                                <span className="text-sm">Non-Compliant</span>
                              </div>
                              <span className="text-sm font-medium">2</span>
                            </div>
                          </div>
                        </div>
                        
                        <Button>View Detailed Compliance Report</Button>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="documents">
                      <div className="space-y-4">
                        <p className="text-neutral-600">Manage and track your document compliance requirements.</p>
                        <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                          <h3 className="text-sm font-medium mb-3">Document Status</h3>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Total Documents Required</span>
                              <span className="text-sm font-medium">12</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Up to Date</span>
                              <span className="text-sm font-medium">7</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Needs Updating</span>
                              <span className="text-sm font-medium">5</span>
                            </div>
                          </div>
                        </div>
                        <Button>Manage Documents</Button>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="training">
                      <div className="space-y-4">
                        <p className="text-neutral-600">Track training compliance for your team members.</p>
                        <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                          <h3 className="text-sm font-medium mb-3">Training Status</h3>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Total Required Trainings</span>
                              <span className="text-sm font-medium">8</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Completed</span>
                              <span className="text-sm font-medium">7</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Pending</span>
                              <span className="text-sm font-medium">1</span>
                            </div>
                          </div>
                        </div>
                        <Button>View Training Schedule</Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function CompanyProfileSkeleton() {
  return (
    <>
      <Skeleton className="w-16 h-16 rounded-md mb-4" />
      <Skeleton className="h-8 w-48 mb-4" />
      
      <div className="space-y-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="flex items-start gap-3">
            <Skeleton className="h-5 w-5 mt-0.5" />
            <div>
              <Skeleton className="h-4 w-24 mb-1" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
        ))}
      </div>
      
      <div className="my-6">
        <Skeleton className="h-px w-full" />
      </div>
      
      <div className="flex justify-between">
        <Skeleton className="h-9 w-32" />
        <Skeleton className="h-9 w-9" />
      </div>
    </>
  );
}

function ComplianceDashboardSkeleton() {
  return (
    <>
      <div className="space-y-6 mb-6">
        <Skeleton className="h-10 w-64" />
      </div>
      
      <div className="space-y-6">
        <div>
          <div className="flex justify-between items-center mb-2">
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-6 w-12" />
          </div>
          <Skeleton className="h-2 w-full" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="h-6 w-12" />
            </div>
            <Skeleton className="h-2 w-full" />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-2">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="h-6 w-12" />
            </div>
            <Skeleton className="h-2 w-full" />
          </div>
        </div>
        
        <Skeleton className="h-36 w-full" />
        
        <Skeleton className="h-9 w-48" />
      </div>
    </>
  );
}
