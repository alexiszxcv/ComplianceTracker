import { ComplianceOverview } from "@/components/dashboard/compliance-overview";
import { RecentAlerts } from "@/components/dashboard/recent-alerts";
import { ComplianceRequirements } from "@/components/dashboard/compliance-requirements";

export default function Dashboard() {
  return (
    <>
      <ComplianceOverview />
      <RecentAlerts />
      <ComplianceRequirements />
    </>
  );
}
