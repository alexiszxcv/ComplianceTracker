import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { 
  Search, 
  FileText, 
  Filter,
  ExternalLink, 
  BookOpen,
  Clock,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { getCategoryColor } from "@/lib/utils";

interface Requirement {
  id: number;
  name: string;
  description: string;
  category: string;
  dueDate: string;
  status: string;
}

export default function Regulations() {
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("All Categories");
  const [status, setStatus] = useState("All Statuses");

  const { data: requirements, isLoading } = useQuery<Requirement[]>({
    queryKey: ['/api/requirements'],
  });

  const { data: categories } = useQuery<string[]>({
    queryKey: ['/api/utils/categories'],
  });

  // Filter requirements based on search, category, and status
  const filteredRequirements = requirements?.filter(req => {
    // Search filter
    if (searchTerm && !req.name.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !req.description.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Category filter
    if (category !== "All Categories" && req.category !== category) return false;
    
    // Status filter
    if (status !== "All Statuses" && req.status !== status) return false;
    
    return true;
  });

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-800 mb-1">Compliance Regulations</h1>
          <p className="text-neutral-500">Browse and search for regulations relevant to your business</p>
        </div>
        <div className="mt-4 md:mt-0 relative w-full md:w-64">
          <Input
            placeholder="Search regulations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
        </div>
      </div>

      <Tabs defaultValue="all">
        <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
          <TabsList>
            <TabsTrigger value="all" className="flex items-center">
              <BookOpen className="mr-2 h-4 w-4" />
              All Regulations
            </TabsTrigger>
            <TabsTrigger value="applicable" className="flex items-center">
              <FileText className="mr-2 h-4 w-4" />
              Applicable to You
            </TabsTrigger>
          </TabsList>
          
          <div className="flex flex-wrap gap-2">
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full md:w-44">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All Categories">All Categories</SelectItem>
                {categories?.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-full md:w-44">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All Statuses">All Statuses</SelectItem>
                <SelectItem value="Compliant">Compliant</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Non-Compliant">Non-Compliant</SelectItem>
                <SelectItem value="Urgent">Urgent</SelectItem>
                <SelectItem value="On Track">On Track</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <TabsContent value="all" className="mt-0">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                {isLoading ? (
                  <RegulationsTableSkeleton />
                ) : (
                  <Table>
                    <TableHeader className="bg-neutral-50">
                      <TableRow>
                        <TableHead className="w-96">Regulation</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Due Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRequirements && filteredRequirements.length > 0 ? (
                        filteredRequirements.map(req => {
                          const categoryColors = getCategoryColor(req.category);
                          
                          return (
                            <TableRow key={req.id}>
                              <TableCell className="font-medium">
                                <div>
                                  <h4 className="text-sm font-medium">{req.name}</h4>
                                  <p className="text-sm text-neutral-500 mt-0.5">{req.description}</p>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge className={`${categoryColors.bg} ${categoryColors.text}`}>
                                  {req.category}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-sm">
                                <div className="flex items-center text-neutral-600">
                                  <Clock className="h-4 w-4 mr-2" />
                                  {req.dueDate}
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className={
                                  req.status === 'Urgent' ? 'border-red-500 text-red-500' :
                                  req.status === 'Non-Compliant' ? 'border-red-500 text-red-500' :
                                  req.status === 'In Progress' ? 'border-yellow-500 text-yellow-500' :
                                  'border-green-500 text-green-500'
                                }>
                                  {req.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button variant="link" size="sm" className="text-primary px-0">
                                  <ExternalLink className="h-4 w-4 mr-2" />
                                  View Details
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="h-24 text-center text-neutral-500">
                            No matching regulations found
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </div>
              
              {!isLoading && (
                <div className="px-4 py-3 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between">
                  <div className="text-sm text-neutral-700">
                    Showing {filteredRequirements?.length || 0} of {requirements?.length || 0} regulations
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" disabled>
                      <ChevronLeft className="h-4 w-4 mr-1" />
                      Previous
                    </Button>
                    <Button variant="outline" size="sm">
                      Next
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="applicable" className="mt-0">
          <Card>
            <CardContent className="p-6 text-center">
              <FileText className="h-12 w-12 mx-auto text-neutral-400 mb-4" />
              <h3 className="text-lg font-medium text-neutral-800 mb-2">Personalized Regulations View</h3>
              <p className="text-neutral-600 mb-6 max-w-md mx-auto">
                Complete your company profile to see regulations specifically applicable to your business.
              </p>
              <Button className="mx-auto">
                Complete Company Profile
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function RegulationsTableSkeleton() {
  return (
    <Table>
      <TableHeader className="bg-neutral-50">
        <TableRow>
          <TableHead className="w-96">Regulation</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Due Date</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {[1, 2, 3, 4].map(i => (
          <TableRow key={i}>
            <TableCell>
              <Skeleton className="h-5 w-48 mb-1" />
              <Skeleton className="h-4 w-72" />
            </TableCell>
            <TableCell>
              <Skeleton className="h-6 w-24 rounded-full" />
            </TableCell>
            <TableCell>
              <Skeleton className="h-4 w-32" />
            </TableCell>
            <TableCell>
              <Skeleton className="h-6 w-20 rounded-full" />
            </TableCell>
            <TableCell>
              <Skeleton className="h-4 w-24" />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
