import { 
  users, type User, type InsertUser,
  companies, type Company, type InsertCompany,
  alerts, type Alert, type InsertAlert,
  requirements, type Requirement, type InsertRequirement,
  industries, categories, statuses
} from "@shared/schema";
import { format } from "date-fns";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Company methods
  getCompany(id: number): Promise<Company | undefined>;
  getAllCompanies(): Promise<Company[]>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompanyScores(id: number, scores: Partial<{
    complianceScore: number;
    documentComplianceScore: number;
    trainingComplianceScore: number;
  }>): Promise<Company | undefined>;
  
  // Alert methods
  getAlert(id: number): Promise<Alert | undefined>;
  getAllAlerts(): Promise<Alert[]>;
  getAlertsByIndustry(industry: string): Promise<Alert[]>;
  markAlertAsRead(id: number): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  
  // Requirement methods
  getRequirement(id: number): Promise<Requirement | undefined>;
  getRequirementsByCompany(companyId: number): Promise<Requirement[]>;
  getRequirementsByStatus(status: string): Promise<Requirement[]>;
  getRequirementsByCategory(category: string): Promise<Requirement[]>;
  createRequirement(requirement: InsertRequirement): Promise<Requirement>;
  updateRequirementStatus(id: number, status: string): Promise<Requirement | undefined>;
  
  // Utility methods
  searchRequirements(term: string): Promise<Requirement[]>;
  getIndustries(): Promise<string[]>;
  getCategories(): Promise<string[]>;
  getStatuses(): Promise<string[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private companies: Map<number, Company>;
  private alerts: Map<number, Alert>;
  private requirements: Map<number, Requirement>;
  private userId: number;
  private companyId: number;
  private alertId: number;
  private requirementId: number;

  constructor() {
    this.users = new Map();
    this.companies = new Map();
    this.alerts = new Map();
    this.requirements = new Map();
    this.userId = 1;
    this.companyId = 1;
    this.alertId = 1;
    this.requirementId = 1;
    
    // Initialize with some sample companies
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample companies
    const acmeCompany: Company = {
      id: this.companyId++,
      name: "Acme Corporation",
      industry: "Manufacturing",
      size: "Medium",
      location: "New York, USA",
      complianceScore: 87,
      documentComplianceScore: 65,
      trainingComplianceScore: 92,
      createdAt: new Date(),
    };
    this.companies.set(1, acmeCompany);
    
    // Sample user
    const sampleUser: User = {
      id: this.userId++,
      username: "sarah.johnson",
      password: "password123", // In a real app, this should be hashed
      name: "Sarah Johnson",
      role: "Account Manager",
      companyId: 1,
    };
    this.users.set(1, sampleUser);
    
    // Sample alerts
    const alerts: InsertAlert[] = [
      {
        title: "New Data Privacy Regulation Effective in 30 Days",
        description: "The new data privacy regulation requires businesses to update their customer data processing protocols by September 15, 2023.",
        category: "Data Privacy",
        severity: "high",
        industry: "All",
        relevantTo: ["Manufacturing", "Technology", "Retail"],
        expiryDate: new Date(2023, 8, 15), // September 15, 2023
      },
      {
        title: "Employee Safety Training Requirements Updated",
        description: "New guidelines for workplace safety training have been issued that affect your business category.",
        category: "Health & Safety",
        severity: "medium",
        industry: "Manufacturing",
        relevantTo: ["Manufacturing", "Construction"],
        expiryDate: new Date(2023, 9, 10), // October 10, 2023
      },
      {
        title: "Tax Filing Deadline Extension",
        description: "The quarterly tax filing deadline has been extended by 15 days for businesses in your region.",
        category: "Financial",
        severity: "low",
        industry: "All",
        relevantTo: ["Manufacturing", "Technology", "Retail", "Financial Services"],
        expiryDate: new Date(2023, 9, 31), // October 31, 2023
      },
      {
        title: "Environmental Reporting Format Changed",
        description: "The environmental protection agency has updated their reporting format for annual submissions.",
        category: "Environmental",
        severity: "low",
        industry: "Manufacturing",
        relevantTo: ["Manufacturing", "Energy"],
        expiryDate: new Date(2023, 11, 15), // December 15, 2023
      }
    ];
    
    // Add 2 weeks ago timestamp to the last alert
    const twoWeeksAgo = new Date();
    twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
    
    // Add 1 week ago timestamp to the third alert
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    // Add 5 days ago timestamp to the second alert
    const fiveDaysAgo = new Date();
    fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5);
    
    // Add 2 days ago timestamp to the first alert
    const twoDaysAgo = new Date();
    twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
    
    alerts.forEach((alert, index) => {
      const alertWithId: Alert = {
        ...alert,
        id: this.alertId++,
        postDate: [twoDaysAgo, fiveDaysAgo, oneWeekAgo, twoWeeksAgo][index],
        isRead: false,
      };
      this.alerts.set(alertWithId.id, alertWithId);
    });
    
    // Sample requirements
    const requirements: InsertRequirement[] = [
      {
        name: "Data Processing Agreement Updates",
        description: "Update all customer data processing agreements",
        category: "Data Privacy",
        dueDate: new Date(2023, 8, 15), // September 15, 2023
        status: "Urgent",
        industry: "Manufacturing",
        companyId: 1,
      },
      {
        name: "Employee Safety Training",
        description: "Update training materials and schedule sessions",
        category: "Health & Safety",
        dueDate: new Date(2023, 9, 10), // October 10, 2023
        status: "In Progress",
        industry: "Manufacturing",
        companyId: 1,
      },
      {
        name: "Quarterly Tax Filing",
        description: "File quarterly tax returns",
        category: "Financial",
        dueDate: new Date(2023, 9, 31), // October 31, 2023
        status: "On Track",
        industry: "Manufacturing",
        companyId: 1,
      },
      {
        name: "Environmental Report",
        description: "Prepare annual environmental impact report",
        category: "Environmental",
        dueDate: new Date(2023, 11, 15), // December 15, 2023
        status: "On Track",
        industry: "Manufacturing",
        companyId: 1,
      }
    ];
    
    requirements.forEach(requirement => {
      const requirementWithId: Requirement = {
        ...requirement,
        id: this.requirementId++,
      };
      this.requirements.set(requirementWithId.id, requirementWithId);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Company methods
  async getCompany(id: number): Promise<Company | undefined> {
    return this.companies.get(id);
  }
  
  async getAllCompanies(): Promise<Company[]> {
    return Array.from(this.companies.values());
  }
  
  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const id = this.companyId++;
    const company: Company = {
      ...insertCompany,
      id,
      complianceScore: 0,
      documentComplianceScore: 0,
      trainingComplianceScore: 0,
      createdAt: new Date(),
    };
    this.companies.set(id, company);
    return company;
  }
  
  async updateCompanyScores(id: number, scores: Partial<{
    complianceScore: number;
    documentComplianceScore: number;
    trainingComplianceScore: number;
  }>): Promise<Company | undefined> {
    const company = this.companies.get(id);
    if (!company) return undefined;
    
    const updatedCompany: Company = {
      ...company,
      ...scores,
    };
    
    this.companies.set(id, updatedCompany);
    return updatedCompany;
  }
  
  // Alert methods
  async getAlert(id: number): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }
  
  async getAllAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .sort((a, b) => b.postDate.getTime() - a.postDate.getTime());
  }
  
  async getAlertsByIndustry(industry: string): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.industry === industry || alert.industry === "All" || alert.relevantTo.includes(industry))
      .sort((a, b) => b.postDate.getTime() - a.postDate.getTime());
  }
  
  async markAlertAsRead(id: number): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert: Alert = {
      ...alert,
      isRead: true,
    };
    
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }
  
  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.alertId++;
    const alert: Alert = {
      ...insertAlert,
      id,
      postDate: new Date(),
      isRead: false,
    };
    this.alerts.set(id, alert);
    return alert;
  }
  
  // Requirement methods
  async getRequirement(id: number): Promise<Requirement | undefined> {
    return this.requirements.get(id);
  }
  
  async getRequirementsByCompany(companyId: number): Promise<Requirement[]> {
    return Array.from(this.requirements.values())
      .filter(requirement => requirement.companyId === companyId)
      .sort((a, b) => {
        if (a.dueDate && b.dueDate) {
          return a.dueDate.getTime() - b.dueDate.getTime();
        }
        return 0;
      });
  }
  
  async getRequirementsByStatus(status: string): Promise<Requirement[]> {
    return Array.from(this.requirements.values())
      .filter(requirement => requirement.status === status)
      .sort((a, b) => {
        if (a.dueDate && b.dueDate) {
          return a.dueDate.getTime() - b.dueDate.getTime();
        }
        return 0;
      });
  }
  
  async getRequirementsByCategory(category: string): Promise<Requirement[]> {
    return Array.from(this.requirements.values())
      .filter(requirement => requirement.category === category)
      .sort((a, b) => {
        if (a.dueDate && b.dueDate) {
          return a.dueDate.getTime() - b.dueDate.getTime();
        }
        return 0;
      });
  }
  
  async createRequirement(insertRequirement: InsertRequirement): Promise<Requirement> {
    const id = this.requirementId++;
    const requirement: Requirement = {
      ...insertRequirement,
      id,
    };
    this.requirements.set(id, requirement);
    return requirement;
  }
  
  async updateRequirementStatus(id: number, status: string): Promise<Requirement | undefined> {
    const requirement = this.requirements.get(id);
    if (!requirement) return undefined;
    
    const updatedRequirement: Requirement = {
      ...requirement,
      status,
    };
    
    this.requirements.set(id, updatedRequirement);
    return updatedRequirement;
  }
  
  // Utility methods
  async searchRequirements(term: string): Promise<Requirement[]> {
    const lowerTerm = term.toLowerCase();
    return Array.from(this.requirements.values())
      .filter(requirement => 
        requirement.name.toLowerCase().includes(lowerTerm) ||
        requirement.description.toLowerCase().includes(lowerTerm) ||
        requirement.category.toLowerCase().includes(lowerTerm)
      )
      .sort((a, b) => {
        if (a.dueDate && b.dueDate) {
          return a.dueDate.getTime() - b.dueDate.getTime();
        }
        return 0;
      });
  }
  
  async getIndustries(): Promise<string[]> {
    return industries;
  }
  
  async getCategories(): Promise<string[]> {
    return categories;
  }
  
  async getStatuses(): Promise<string[]> {
    return statuses;
  }
}

export const storage = new MemStorage();
