import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import {
  insertUserSchema,
  insertCompanySchema,
  insertAlertSchema,
  insertRequirementSchema,
  industries,
  categories,
  statuses
} from "@shared/schema";
import { ZodError } from "zod";
import { format } from "date-fns";

export async function registerRoutes(app: Express): Promise<Server> {
  // Helper middleware to handle zod validation errors
  const validateRequest = (schema: z.ZodType<any, any>) => {
    return (req: Request, res: Response, next: () => void) => {
      try {
        req.body = schema.parse(req.body);
        next();
      } catch (error) {
        if (error instanceof ZodError) {
          res.status(400).json({
            message: "Validation error",
            errors: error.errors,
          });
        } else {
          next();
        }
      }
    };
  };

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const user = await storage.getUser(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    // Don't send password in the response
    const { password, ...userWithoutPassword } = user;
    res.status(200).json(userWithoutPassword);
  });

  app.post("/api/users", validateRequest(insertUserSchema), async (req, res) => {
    const existingUser = await storage.getUserByUsername(req.body.username);
    if (existingUser) {
      return res.status(400).json({ message: "Username already exists" });
    }
    const user = await storage.createUser(req.body);
    // Don't send password in the response
    const { password, ...userWithoutPassword } = user;
    res.status(201).json(userWithoutPassword);
  });

  // Company routes
  app.get("/api/companies/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const company = await storage.getCompany(id);
    if (!company) {
      return res.status(404).json({ message: "Company not found" });
    }
    res.status(200).json(company);
  });

  app.get("/api/companies", async (req, res) => {
    const companies = await storage.getAllCompanies();
    res.status(200).json(companies);
  });

  app.post("/api/companies", validateRequest(insertCompanySchema), async (req, res) => {
    const company = await storage.createCompany(req.body);
    res.status(201).json(company);
  });

  app.patch("/api/companies/:id/scores", async (req, res) => {
    const id = parseInt(req.params.id);
    const { complianceScore, documentComplianceScore, trainingComplianceScore } = req.body;
    
    const scores: Record<string, number> = {};
    if (complianceScore !== undefined) scores.complianceScore = complianceScore;
    if (documentComplianceScore !== undefined) scores.documentComplianceScore = documentComplianceScore;
    if (trainingComplianceScore !== undefined) scores.trainingComplianceScore = trainingComplianceScore;
    
    const company = await storage.updateCompanyScores(id, scores);
    if (!company) {
      return res.status(404).json({ message: "Company not found" });
    }
    res.status(200).json(company);
  });

  // Alert routes
  app.get("/api/alerts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const alert = await storage.getAlert(id);
    if (!alert) {
      return res.status(404).json({ message: "Alert not found" });
    }
    
    // Mark as read when viewed in detail
    await storage.markAlertAsRead(id);
    
    res.status(200).json(alert);
  });

  app.get("/api/alerts", async (req, res) => {
    const industry = req.query.industry as string | undefined;
    
    let alerts;
    if (industry) {
      alerts = await storage.getAlertsByIndustry(industry);
    } else {
      alerts = await storage.getAllAlerts();
    }
    
    res.status(200).json(alerts);
  });

  app.post("/api/alerts/:id/read", async (req, res) => {
    const id = parseInt(req.params.id);
    const alert = await storage.markAlertAsRead(id);
    if (!alert) {
      return res.status(404).json({ message: "Alert not found" });
    }
    res.status(200).json(alert);
  });

  app.post("/api/alerts", validateRequest(insertAlertSchema), async (req, res) => {
    const alert = await storage.createAlert(req.body);
    res.status(201).json(alert);
  });

  // Requirement routes
  app.get("/api/requirements/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const requirement = await storage.getRequirement(id);
    if (!requirement) {
      return res.status(404).json({ message: "Requirement not found" });
    }
    
    // Format dates to be more readable
    const formattedRequirement = {
      ...requirement,
      dueDate: requirement.dueDate ? format(requirement.dueDate, 'PPP') : null,
    };
    
    res.status(200).json(formattedRequirement);
  });

  app.get("/api/requirements", async (req, res) => {
    const companyId = req.query.companyId ? parseInt(req.query.companyId as string) : undefined;
    const status = req.query.status as string | undefined;
    const category = req.query.category as string | undefined;
    const search = req.query.search as string | undefined;
    
    let requirements;
    if (search) {
      requirements = await storage.searchRequirements(search);
    } else if (companyId) {
      requirements = await storage.getRequirementsByCompany(companyId);
    } else if (status) {
      requirements = await storage.getRequirementsByStatus(status);
    } else if (category) {
      requirements = await storage.getRequirementsByCategory(category);
    } else {
      requirements = await storage.getRequirementsByCompany(1); // Default to first company
    }
    
    // Format dates to be more readable
    const formattedRequirements = requirements.map(requirement => ({
      ...requirement,
      dueDate: requirement.dueDate ? format(requirement.dueDate, 'PPP') : null,
    }));
    
    res.status(200).json(formattedRequirements);
  });

  app.post("/api/requirements", validateRequest(insertRequirementSchema), async (req, res) => {
    const requirement = await storage.createRequirement(req.body);
    res.status(201).json(requirement);
  });

  app.patch("/api/requirements/:id/status", async (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!status || !statuses.includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }
    
    const requirement = await storage.updateRequirementStatus(id, status);
    if (!requirement) {
      return res.status(404).json({ message: "Requirement not found" });
    }
    res.status(200).json(requirement);
  });

  // Utility routes
  app.get("/api/utils/industries", async (req, res) => {
    const industriesList = await storage.getIndustries();
    res.status(200).json(industriesList);
  });

  app.get("/api/utils/categories", async (req, res) => {
    const categoriesList = await storage.getCategories();
    res.status(200).json(categoriesList);
  });

  app.get("/api/utils/statuses", async (req, res) => {
    const statusesList = await storage.getStatuses();
    res.status(200).json(statusesList);
  });

  const httpServer = createServer(app);
  return httpServer;
}
